# pertemuan-08

NIM : 2511500001<br>
Nama : Richie Christian<br>

Hari ini, Rabu 25 November 2025 saya mempelajari:
<ol>
<li>latihan untuk ubah data post ke array associative</li>
<li>Modif baris 10-19</li>
<li>Menghapus dan memodifikasi kode pada baris 23-32</li>
<li>Hapus kode baris 19-67 dan modifikasi kodenya</li>
<li>menambahkan kode baru pada baris <h2>Tentang saya</h2> untuk menampilkan array menggunakan    looping foreach</li>
<li>hapus baris 130-139 untuk menampilkan isi array associative $fieldConfig</li>
<li>membuat file baru fungsi.php</li>
<li>tambahkan kode di bahan ajar pada file fungsi.php</li>
<li>menambahkan kode untuk menghasilkan tanggal dalam format 2 digit tanggal, 3 digit nama bulan,
dan 4 digit tahun</li>
<li>kode pada fungsi.php untuk merender hasil atau output biodata</li>
<li>hapus kode baris 123-128 pada index.php dan ganti dengan kode dibahan ajar</li>
<li>tambahkan kode require_once pada file index.php</li>
<li>membuat kode yag sama pada section contact</li>
</ol>
